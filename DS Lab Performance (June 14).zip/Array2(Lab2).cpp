#include<iostream>
using namespace std;
int main()
{
    int n=6;
    int A[n];
    int B[n];
    int C[n];
    cout<<"Enter the elements of the array 1 : "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>A[i];
    }
    cout<<endl;
    cout<<"Enter the elements of the array 2 : "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>B[i];
    }
    cout<<endl;
    cout<<"Array 1: ";
    for(int i=0;i<n;i++)
    {
        cout<<A[i]<<" ";
    }
    cout<<endl;
    cout<<"Array 2 : ";
    for(int i=0;i<n;i++)
    {
        cout<<B[i]<<" ";
    }
    cout<<endl;
    int ran=0;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(A[i]==B[j])
            {
                C[ran]=B[j];
                ran++;
            }
        }
    }
    if(ran>0)
    {
        cout<<"The new array : ";
        for(int i=0;i<ran;i++)
        {
            cout<<C[i]<<" ";
        }
    }
    else
    {
        cout<<"No common element!"<<endl;
    }
    return 0;
}
