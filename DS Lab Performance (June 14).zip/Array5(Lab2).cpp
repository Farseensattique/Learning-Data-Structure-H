#include<iostream>
using namespace std;

int main()
{
    int n = 10;
    int arr[n];
    cout << "Enter the elements of the array: " << endl;
    for(int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << "The array: ";
    for(int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;

    for(int i = 0; i < n; i++)
    {
        int z = 0;
        bool a = false;

        for(int j = 0; j < i; j++)
        {
            if(arr[i] == arr[j])
            {
                a= true;
                break;
            }
        }

        if(!a)
        {
            for(int j = 0; j < n; j++)
            {
                if(arr[i] == arr[j])
                {
                    z++;
                }
            }
            cout << arr[i] << " occurs = " << z << " times" << endl;
        }
    }

    return 0;
}

