#include<iostream>
using namespace std;
int main()
{
    int n=10;
    int arr[n];
    cout<<"Enter the elements of the array : "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    cout<<"The array : ";
    for(int i=0;i<n;i++)
    {
        cout<<arr[i]<<" ";
    }
    cout<<endl;
    int ran=0, s;
    cout<<"Enter the number to be searched : "<<endl;
    cin>>s;
    for(int i=0;i<n;i++)
    {
            if(arr[i]==s)
            {
                ran++;
            }

    }
    cout<<"The number '"<<s<<"' occurs "<<ran<<" times in the array"<<endl;
    return 0;

}
