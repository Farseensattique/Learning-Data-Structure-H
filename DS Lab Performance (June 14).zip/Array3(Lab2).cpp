#include<iostream>
using namespace std;
int main()
{
    int n;
    cout<<"Enter the size of the array : ";
    cin>>n;
    int arr[n];
    cout<<"Enter the elements of the array : "<<endl;
    for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
    bool a = false;

    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (arr[i] == arr[j])
            {
                a = true;
                break;
            }
        }
        if (a)
        {
            break;
        }
    }
    if(a)
    {
        int arr1[n];
        int ran=0;
        for(int i=0;i<n;i++)
        {
            bool d=false;
            for(int j=i+1;j<n;j++)
            {
                if(arr[i]==arr[j])
                {
                   d=true;
                   break;
                }
            }
            if(!d)
            {
                arr1[ran]=arr[i];;
                ran++;
            }
        }
        cout << "The new array without duplicate elements: " << endl;
        for(int i=0;i<ran;i++)
        {
            cout<<arr1[i]<<" ";
        }
    }
    else
    {
        cout<<"Array is already unique!"<<endl;
    }

    return 0;
}
